//Assign the copied API key to the 'key' variable
key = "441de417284a824bf3412df7b59c6940";